export interface DashboardData {
  user: {
    id: string;
    name: string;
    role: string;
    goal: string;
  };
  competencies: Array<{
    id: string;
    name: string;
    category: string;
    description: string;
    skills: string[];
    currentLevel: number;
    targetLevel: number;
    progress: number;
  }>;
  milestones: Array<{
    id: string;
    title: string;
    description: string;
    status: string;
    progress: number;
    targetDate?: Date;
    completedAt?: Date;
    order: number;
  }>;
  actionItems: Array<{
    id: string;
    title: string;
    description?: string;
    completed: boolean;
    priority: string;
    dueDate?: Date;
  }>;
  resources: Array<{
    id: string;
    title: string;
    type: string;
    description: string;
    author?: string;
    rating?: number;
    imageUrl?: string;
  }>;
  overallProgress: {
    strategic: number;
    financial: number;
    leadership: number;
    stakeholder: number;
  };
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: Date;
}

export interface CoachingSession {
  id: string;
  userId: string;
  title: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ChatResponse {
  userMessage: ChatMessage;
  aiMessage: ChatMessage;
  followUpQuestions?: string[];
  actionItems?: string[];
  competencyFocus?: string;
}
