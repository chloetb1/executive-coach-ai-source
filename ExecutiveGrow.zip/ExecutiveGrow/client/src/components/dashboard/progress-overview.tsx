import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface ProgressOverviewProps {
  competencies: Array<{
    id: string;
    name: string;
    category: string;
    description: string;
    currentLevel: number;
    targetLevel: number;
    progress: number;
  }>;
}

export default function ProgressOverview({ competencies }: ProgressOverviewProps) {
  return (
    <Card className="p-6 executive-shadow animate-slide-up" data-testid="card-progress-overview">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-bold text-gray-900" data-testid="text-progress-title">
          Development Progress
        </h3>
        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium" data-testid="status-progress">
          On Track
        </span>
      </div>
      
      <div className="space-y-6">
        {competencies.map((competency) => {
          const progressPercent = (competency.currentLevel / competency.targetLevel) * 100;
          const colorClass = 
            progressPercent >= 70 ? "from-green-500 to-green-400" :
            progressPercent >= 50 ? "from-executive-500 to-executive-400" :
            "from-gold-500 to-gold-400";
          
          return (
            <div key={competency.id} className="bg-gray-50 rounded-xl p-4" data-testid={`competency-${competency.id}`}>
              <div className="flex justify-between items-center mb-3">
                <span className="font-semibold text-gray-900" data-testid={`text-competency-name-${competency.id}`}>
                  {competency.name}
                </span>
                <span className="text-executive-600 font-bold" data-testid={`text-competency-level-${competency.id}`}>
                  {Math.round(progressPercent)}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
                <div 
                  className={`bg-gradient-to-r ${colorClass} h-3 rounded-full transition-all duration-1000 ease-out`}
                  style={{ width: `${progressPercent}%` }}
                  data-testid={`progress-bar-${competency.id}`}
                />
              </div>
              <p className="text-sm text-gray-600" data-testid={`text-competency-description-${competency.id}`}>
                {competency.description}
              </p>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
