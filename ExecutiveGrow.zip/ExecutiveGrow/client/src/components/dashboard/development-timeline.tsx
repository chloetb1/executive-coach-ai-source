import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, Clock, Circle, Star, ExternalLink, User } from "lucide-react";

interface DevelopmentTimelineProps {
  milestones: Array<{
    id: string;
    title: string;
    description: string;
    status: string;
    progress: number;
    targetDate?: Date;
    completedAt?: Date;
    order: number;
  }>;
  resources: Array<{
    id: string;
    title: string;
    type: string;
    description: string;
    author?: string;
    rating?: number;
    imageUrl?: string;
  }>;
}

export default function DevelopmentTimeline({ milestones, resources }: DevelopmentTimelineProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle size={16} className="text-green-500" data-testid="icon-completed" />;
      case "in-progress":
        return <Clock size={16} className="text-executive-500 animate-pulse" data-testid="icon-in-progress" />;
      default:
        return <Circle size={16} className="text-gray-300" data-testid="icon-pending" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "border-green-200 bg-green-50";
      case "in-progress":
        return "border-executive-200 bg-executive-50 border-2";
      default:
        return "border-gray-200 bg-gray-50";
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-600";
      case "in-progress":
        return "bg-executive-100 text-executive-600";
      default:
        return "bg-gray-100 text-gray-500";
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Timeline */}
      <div className="lg:col-span-2">
        <Card className="p-6 executive-shadow" data-testid="card-development-timeline">
          <h3 className="text-2xl font-bold text-gray-900 mb-6" data-testid="text-timeline-title">
            Development Roadmap
          </h3>
          
          <div className="relative">
            <div className="absolute left-4 top-0 bottom-0 w-px bg-gray-300" data-testid="timeline-line" />
            
            <div className="space-y-6">
              {milestones.map((milestone) => (
                <div key={milestone.id} className="relative flex items-start" data-testid={`milestone-${milestone.id}`}>
                  <div className="absolute left-4 w-2 h-2 bg-gray-500 rounded-full transform -translate-x-1/2 mt-2">
                    {getStatusIcon(milestone.status)}
                  </div>
                  <div className={`ml-12 rounded-xl p-4 border ${getStatusColor(milestone.status)}`}>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-gray-800" data-testid={`text-milestone-title-${milestone.id}`}>
                        {milestone.title}
                      </h4>
                      <span className={`text-xs px-2 py-1 rounded-full uppercase tracking-wide ${getStatusBadge(milestone.status)}`} data-testid={`badge-milestone-status-${milestone.id}`}>
                        {milestone.status.replace('-', ' ')}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700 mb-3" data-testid={`text-milestone-description-${milestone.id}`}>
                      {milestone.description}
                    </p>
                    {milestone.status === "in-progress" && (
                      <div className="flex items-center space-x-4">
                        <div className="flex-1">
                          <Progress value={milestone.progress} className="h-2" data-testid={`progress-milestone-${milestone.id}`} />
                        </div>
                        <span className="text-sm font-bold text-executive-600" data-testid={`text-milestone-percentage-${milestone.id}`}>
                          {milestone.progress}%
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>
      
      {/* Resources & Action Items */}
      <div className="space-y-6">
        <Card className="p-6 executive-shadow" data-testid="card-recommended-resources">
          <h3 className="text-xl font-bold text-gray-900 mb-4" data-testid="text-resources-title">
            Recommended Resources
          </h3>
          
          <div className="space-y-4">
            {resources.map((resource) => (
              <div 
                key={resource.id}
                className="border border-gray-200 rounded-xl p-4 hover:border-executive-300 transition-all cursor-pointer"
                data-testid={`resource-${resource.id}`}
              >
                <div className="flex items-center space-x-3">
                  {resource.imageUrl ? (
                    <img 
                      src={resource.imageUrl} 
                      alt={`${resource.title} cover`}
                      className="w-12 h-16 object-cover rounded"
                      data-testid={`img-resource-${resource.id}`}
                    />
                  ) : (
                    <div className="w-12 h-16 bg-gray-200 rounded flex items-center justify-center">
                      {resource.type === "mentor" ? <User className="text-gray-400" size={20} /> : <ExternalLink className="text-gray-400" size={20} />}
                    </div>
                  )}
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 text-sm" data-testid={`text-resource-title-${resource.id}`}>
                      {resource.title}
                    </h4>
                    <p className="text-xs text-gray-600" data-testid={`text-resource-description-${resource.id}`}>
                      {resource.description}
                    </p>
                    {resource.rating && (
                      <div className="flex items-center mt-1">
                        <div className="flex text-gold-400">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              size={12} 
                              className={i < Math.floor(resource.rating!) ? "fill-current" : ""} 
                              data-testid={`star-resource-${resource.id}-${i}`}
                            />
                          ))}
                        </div>
                        <span className="text-xs text-gray-500 ml-1" data-testid={`text-resource-rating-${resource.id}`}>
                          {resource.rating}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
