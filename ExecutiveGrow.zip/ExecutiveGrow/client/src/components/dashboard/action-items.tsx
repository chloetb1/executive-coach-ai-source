import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ActionItemsProps {
  actionItems: Array<{
    id: string;
    title: string;
    description?: string;
    completed: boolean;
    priority: string;
    dueDate?: Date;
  }>;
}

export default function ActionItems({ actionItems }: ActionItemsProps) {
  const [items, setItems] = useState(actionItems);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateActionItemMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: string; completed: boolean }) => {
      return apiRequest("PATCH", `/api/action-items/${id}`, { completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/user-1"] });
      toast({
        title: "Action item updated",
        description: "Your progress has been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update action item. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleToggleComplete = (id: string, completed: boolean) => {
    // Optimistic update
    setItems(prev => prev.map(item => 
      item.id === id ? { ...item, completed } : item
    ));
    
    updateActionItemMutation.mutate({ id, completed });
  };

  return (
    <Card className="p-6 executive-shadow" data-testid="card-action-items">
      <h3 className="text-xl font-bold text-gray-900 mb-4" data-testid="text-action-items-title">
        This Week's Action Items
      </h3>
      
      <div className="space-y-3">
        {items.map((item) => (
          <div 
            key={item.id}
            className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg"
            data-testid={`action-item-${item.id}`}
          >
            <Checkbox
              checked={item.completed}
              onCheckedChange={(checked) => handleToggleComplete(item.id, checked as boolean)}
              className="data-[state=checked]:bg-executive-600 data-[state=checked]:border-executive-600"
              data-testid={`checkbox-action-${item.id}`}
            />
            <span 
              className={`text-sm flex-1 ${
                item.completed 
                  ? "text-gray-500 line-through" 
                  : "text-gray-800"
              }`}
              data-testid={`text-action-title-${item.id}`}
            >
              {item.title}
            </span>
            {item.priority === "high" && (
              <span 
                className="bg-red-100 text-red-700 px-2 py-1 rounded text-xs font-medium"
                data-testid={`badge-priority-${item.id}`}
              >
                High
              </span>
            )}
          </div>
        ))}
      </div>
      
      <Button 
        variant="ghost" 
        className="w-full mt-4 text-executive-600 hover:text-executive-700 hover:bg-executive-50"
        data-testid="button-add-action-item"
      >
        <Plus size={16} className="mr-2" />
        Add Action Item
      </Button>
    </Card>
  );
}
