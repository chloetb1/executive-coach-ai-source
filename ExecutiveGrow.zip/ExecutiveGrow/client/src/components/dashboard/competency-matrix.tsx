import { Card } from "@/components/ui/card";
import { Check, Triangle, X } from "lucide-react";

interface CompetencyMatrixProps {
  competencies: Array<{
    id: string;
    name: string;
    category: string;
    skills: string[];
    currentLevel: number;
    targetLevel: number;
  }>;
  overallProgress: {
    strategic: number;
    financial: number;
    leadership: number;
    stakeholder: number;
  };
}

export default function CompetencyMatrix({ competencies, overallProgress }: CompetencyMatrixProps) {
  const categoryData = [
    {
      name: "Strategic",
      category: "strategic",
      score: overallProgress.strategic,
      gradient: "from-executive-50 to-executive-100",
      border: "border-executive-200",
      textColor: "text-executive-900"
    },
    {
      name: "Financial",
      category: "financial",
      score: overallProgress.financial,
      gradient: "from-gold-50 to-gold-100",
      border: "border-gold-200",
      textColor: "text-gray-900"
    },
    {
      name: "Leadership",
      category: "leadership",
      score: overallProgress.leadership,
      gradient: "from-green-50 to-green-100",
      border: "border-green-200",
      textColor: "text-gray-900"
    },
    {
      name: "Stakeholder",
      category: "stakeholder",
      score: overallProgress.stakeholder,
      gradient: "from-blue-50 to-blue-100",
      border: "border-blue-200",
      textColor: "text-gray-900"
    }
  ];

  const getSkillStatus = (level: number, skillIndex: number, totalSkills: number) => {
    const skillThreshold = ((skillIndex + 1) / totalSkills) * 10;
    if (level >= skillThreshold) return "completed";
    if (level >= skillThreshold - 2) return "in-progress";
    return "not-started";
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <Check size={16} className="text-green-600" data-testid="icon-check" />;
      case "in-progress":
        return <Triangle size={16} className="text-gold-500" data-testid="icon-triangle" />;
      default:
        return <X size={16} className="text-red-500" data-testid="icon-x" />;
    }
  };

  return (
    <Card className="p-6 executive-shadow" data-testid="card-competency-matrix">
      <h3 className="text-2xl font-bold text-gray-900 mb-6" data-testid="text-competency-matrix-title">
        Executive Competency Matrix
      </h3>
      
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          {categoryData.map((category) => {
            const competency = competencies.find(c => c.category === category.category);
            return (
              <div 
                key={category.category}
                className={`bg-gradient-to-br ${category.gradient} rounded-xl p-4 border ${category.border}`}
                data-testid={`competency-category-${category.category}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className={`font-bold ${category.textColor}`} data-testid={`text-category-name-${category.category}`}>
                    {category.name}
                  </h4>
                  <span className={`font-bold ${category.textColor.replace('gray-900', 'gray-600')}`} data-testid={`text-category-score-${category.category}`}>
                    {category.score.toFixed(1)}/10
                  </span>
                </div>
                <div className="space-y-2 text-sm">
                  {competency?.skills.slice(0, 3).map((skill, index) => {
                    const status = getSkillStatus(competency.currentLevel, index, competency.skills.length);
                    return (
                      <div 
                        key={skill} 
                        className="flex justify-between items-center"
                        data-testid={`skill-${category.category}-${index}`}
                      >
                        <span className="text-gray-600" data-testid={`text-skill-name-${category.category}-${index}`}>
                          {skill}
                        </span>
                        <span data-testid={`skill-status-${category.category}-${index}`}>
                          {getStatusIcon(status)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
      <div className="mt-6 p-4 bg-gray-50 rounded-xl" data-testid="priority-development-areas">
        <h4 className="font-bold text-gray-900 mb-2" data-testid="text-priority-areas-title">
          Priority Development Areas
        </h4>
        <div className="flex flex-wrap gap-2">
          <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm" data-testid="priority-tag-financial">
            P&L Management
          </span>
          <span className="bg-gold-100 text-gold-700 px-3 py-1 rounded-full text-sm" data-testid="priority-tag-presence">
            Executive Presence
          </span>
          <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm" data-testid="priority-tag-communication">
            Board Communication
          </span>
        </div>
      </div>
    </Card>
  );
}
