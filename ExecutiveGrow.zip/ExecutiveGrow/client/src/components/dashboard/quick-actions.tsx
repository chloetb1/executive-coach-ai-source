import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageCircle, ClipboardCheck, CheckSquare, Trophy } from "lucide-react";
import { Link } from "wouter";

export default function QuickActions() {
  return (
    <div className="space-y-6">
      <Card className="p-6 executive-shadow animate-slide-up" data-testid="card-quick-actions">
        <h3 className="text-xl font-bold text-gray-900 mb-4" data-testid="text-quick-actions-title">
          Today's Focus
        </h3>
        <div className="space-y-3">
          <Link href="/coaching" data-testid="link-coaching-session">
            <Button className="w-full bg-gradient-to-r from-executive-600 to-executive-500 text-white p-4 h-auto hover:from-executive-700 hover:to-executive-600 transition-all duration-300 transform hover:scale-105">
              <div className="flex items-center justify-between w-full">
                <span className="font-semibold">Start Coaching Session</span>
                <MessageCircle size={20} />
              </div>
            </Button>
          </Link>
          
          <Button 
            variant="outline" 
            className="w-full p-4 h-auto text-gray-800 border-gray-200 hover:border-executive-300 hover:bg-gray-50 transition-all duration-300"
            data-testid="button-assessment"
          >
            <div className="flex items-center justify-between w-full">
              <span className="font-semibold">Complete Assessment</span>
              <ClipboardCheck size={20} className="text-gold-500" />
            </div>
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full p-4 h-auto text-gray-800 border-gray-200 hover:border-executive-300 hover:bg-gray-50 transition-all duration-300"
            data-testid="button-action-items"
          >
            <div className="flex items-center justify-between w-full">
              <span className="font-semibold">Review Action Items</span>
              <CheckSquare size={20} className="text-executive-500" />
            </div>
          </Button>
        </div>
      </Card>
      
      {/* Next Milestone */}
      <div className="bg-gradient-to-br from-gold-50 to-gold-100 rounded-2xl p-6 border border-gold-200" data-testid="card-next-milestone">
        <div className="flex items-center mb-3">
          <Trophy className="text-gold-500 mr-3" size={20} data-testid="icon-trophy" />
          <h3 className="text-lg font-bold text-gray-900" data-testid="text-milestone-title">
            Next Milestone
          </h3>
        </div>
        <p className="text-gray-700 font-medium mb-2" data-testid="text-milestone-name">
          Lead Cross-Functional Sustainability Project
        </p>
        <p className="text-sm text-gray-600 mb-4" data-testid="text-milestone-description">
          Demonstrate strategic leadership by managing a complex initiative involving multiple departments and external stakeholders.
        </p>
        <div className="bg-white rounded-lg p-3">
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600">Progress</span>
            <span className="font-bold text-gold-600" data-testid="text-milestone-progress">3 of 7 steps</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
            <div 
              className="bg-gradient-to-r from-gold-500 to-gold-400 h-2 rounded-full" 
              style={{ width: "43%" }}
              data-testid="progress-milestone"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
