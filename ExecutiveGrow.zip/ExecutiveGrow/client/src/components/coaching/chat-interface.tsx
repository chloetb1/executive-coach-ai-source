import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Send, Mic, Bot, User, CircleDot, Lightbulb, CheckSquare } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import type { ChatMessage, ChatResponse } from "@/lib/types";

interface ChatInterfaceProps {
  sessionId: string;
  messages: ChatMessage[];
  isLoading?: boolean;
  className?: string;
  onMessageSent?: (response: ChatResponse) => void;
}

export default function ChatInterface({
  sessionId,
  messages,
  isLoading = false,
  className,
  onMessageSent
}: ChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/chat-messages", {
        sessionId,
        role: "user",
        content
      });
      return await response.json() as ChatResponse;
    },
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat-messages", sessionId] });
      setMessage("");
      onMessageSent?.(response);
      
      if (response.actionItems && response.actionItems.length > 0) {
        toast({
          title: "New Action Items Created",
          description: `${response.actionItems.length} action item(s) added to your development plan.`,
        });
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!message.trim()) return;
    sendMessageMutation.mutate(message);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getMessageTime = (createdAt: Date) => {
    return new Date(createdAt).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <Card className={cn("flex flex-col", className)} data-testid="chat-interface">
      {/* Chat Header */}
      <div className="flex items-center justify-between p-4 border-b bg-gray-50/50">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-r from-executive-600 to-executive-500 rounded-full flex items-center justify-center">
            <Bot className="text-white" size={20} data-testid="icon-chat-bot" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900" data-testid="text-coach-name">
              Executive Coach AI
            </h3>
            <div className="flex items-center space-x-2">
              <CircleDot className="w-2 h-2 text-green-400 animate-pulse" data-testid="icon-active-status" />
              <span className="text-xs text-gray-600" data-testid="text-session-status">
                Active Session
              </span>
            </div>
          </div>
        </div>
        
        <Badge variant="outline" className="bg-executive-50 border-executive-200 text-executive-700" data-testid="badge-coaching-mode">
          Coaching Mode
        </Badge>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[400px] max-h-[500px]" data-testid="messages-area">
        {isLoading ? (
          <div className="flex items-center justify-center h-full" data-testid="loading-messages">
            <Loader2 className="h-8 w-8 animate-spin text-executive-600" />
          </div>
        ) : messages.length > 0 ? (
          messages.map((msg, index) => (
            <div 
              key={msg.id}
              className={cn(
                "flex items-start space-x-3 chat-bubble",
                msg.role === "user" ? "justify-end" : ""
              )}
              data-testid={`message-${msg.id}`}
            >
              {msg.role === "assistant" && (
                <div className="w-8 h-8 bg-gradient-to-r from-executive-600 to-executive-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="text-white" size={16} data-testid={`bot-avatar-${index}`} />
                </div>
              )}
              
              <div className={cn(
                "max-w-[70%] rounded-2xl p-4",
                msg.role === "assistant" 
                  ? "bg-white border border-gray-200 rounded-tl-sm shadow-sm" 
                  : "bg-executive-600 text-white rounded-tr-sm"
              )}>
                <p className={cn(
                  "text-sm leading-relaxed",
                  msg.role === "assistant" ? "text-gray-800" : "text-white"
                )} data-testid={`message-content-${msg.id}`}>
                  {msg.content}
                </p>
                <span className={cn(
                  "text-xs mt-2 block",
                  msg.role === "assistant" ? "text-gray-500" : "text-white/70"
                )} data-testid={`message-time-${msg.id}`}>
                  {getMessageTime(msg.createdAt)}
                </span>
              </div>

              {msg.role === "user" && (
                <div className="w-8 h-8 bg-gradient-to-r from-gold-500 to-gold-400 rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="text-white" size={16} data-testid={`user-avatar-${index}`} />
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center max-w-md" data-testid="welcome-message">
              <div className="w-16 h-16 bg-gradient-to-r from-executive-600 to-executive-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Bot className="text-white" size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Ready for Executive Coaching?
              </h3>
              <p className="text-gray-600 text-sm mb-6">
                I'm here to help you develop the leadership competencies needed for senior sustainability roles. Start by sharing a challenge or asking about specific skills.
              </p>
              
              {/* Suggested Topics */}
              <div className="space-y-2">
                <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                  Suggested Topics:
                </p>
                <div className="flex flex-wrap gap-2 justify-center">
                  {[
                    "Strategic thinking",
                    "Financial acumen", 
                    "Executive presence",
                    "Stakeholder management"
                  ].map((topic) => (
                    <Button
                      key={topic}
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => setMessage(`I want to improve my ${topic} skills. Where should I start?`)}
                      data-testid={`button-topic-${topic.replace(' ', '-')}`}
                    >
                      {topic}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-4 border-t bg-gray-50/50" data-testid="input-area">
        <div className="flex items-end space-x-3">
          <div className="flex-1 relative">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask about leadership development, share a challenge, or request specific guidance..."
              className="min-h-[44px] pr-12 resize-none"
              disabled={sendMessageMutation.isPending}
              data-testid="input-chat-message"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!message.trim() || sendMessageMutation.isPending}
              size="sm"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
              data-testid="button-send-message"
            >
              {sendMessageMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            className="h-11 w-11 p-0"
            disabled={sendMessageMutation.isPending}
            data-testid="button-voice-input"
          >
            <Mic className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Coaching Tips */}
        <div className="mt-3 flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Lightbulb className="h-3 w-3" data-testid="icon-tip" />
              <span>Pro tip: Be specific about your challenges for better guidance</span>
            </div>
          </div>
          <div className="flex items-center space-x-1" data-testid="keyboard-shortcut">
            <span>Press</span>
            <kbd className="px-2 py-0.5 bg-gray-200 rounded text-xs">Enter</kbd>
            <span>to send</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
