import { Link, useLocation } from "wouter";
import { Brain, Bell } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const [location] = useLocation();

  const navItems = [
    { href: "/dashboard", label: "Dashboard" },
    { href: "/coaching", label: "Coaching" },
    { href: "/progress", label: "Progress" },
    { href: "/resources", label: "Resources" },
  ];

  return (
    <nav className="bg-white/80 backdrop-blur-md border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" data-testid="link-home">
            <div className="flex items-center space-x-3 cursor-pointer">
              <div className="w-10 h-10 bg-gradient-to-r from-executive-600 to-executive-500 rounded-xl flex items-center justify-center">
                <Brain className="text-white" size={20} data-testid="icon-brain" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-executive-900" data-testid="text-app-title">
                  Executive Coach AI
                </h1>
                <p className="text-xs text-gray-500" data-testid="text-app-subtitle">
                  Sustainability Leadership
                </p>
              </div>
            </div>
          </Link>
          
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href} data-testid={`link-nav-${item.label.toLowerCase()}`}>
                <span
                  className={cn(
                    "font-medium transition-colors cursor-pointer",
                    location === item.href || (location === "/" && item.href === "/dashboard")
                      ? "text-executive-600"
                      : "text-gray-600 hover:text-executive-600"
                  )}
                >
                  {item.label}
                </span>
              </Link>
            ))}
          </div>
          
          <div className="flex items-center space-x-4">
            <button 
              className="p-2 text-gray-500 hover:text-executive-600 transition-colors"
              data-testid="button-notifications"
            >
              <Bell size={20} />
            </button>
            <div 
              className="w-8 h-8 bg-gradient-to-r from-gold-500 to-gold-400 rounded-full flex items-center justify-center"
              data-testid="avatar-user"
            >
              <span className="text-white text-sm font-medium">SC</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
