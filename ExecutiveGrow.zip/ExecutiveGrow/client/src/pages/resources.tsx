import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Loader2, 
  BookOpen, 
  PlayCircle, 
  User, 
  ExternalLink, 
  Star, 
  Search,
  Filter,
  Grid,
  List,
  Download
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Resource {
  id: string;
  title: string;
  type: "book" | "course" | "mentor" | "article";
  description: string;
  url?: string;
  author?: string;
  rating?: number;
  competencyId?: string;
  imageUrl?: string;
}

interface Competency {
  id: string;
  name: string;
  category: string;
}

export default function Resources() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [selectedCompetency, setSelectedCompetency] = useState<string>("all");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const { data: resources, isLoading: resourcesLoading } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });

  const { data: competencies } = useQuery<Competency[]>({
    queryKey: ["/api/competencies"],
  });

  // Filter resources based on search and filters
  const filteredResources = resources?.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         resource.author?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesType = selectedType === "all" || resource.type === selectedType;
    
    const matchesCompetency = selectedCompetency === "all" || resource.competencyId === selectedCompetency;
    
    return matchesSearch && matchesType && matchesCompetency;
  }) || [];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "book":
        return <BookOpen className="h-5 w-5" data-testid="icon-book" />;
      case "course":
        return <PlayCircle className="h-5 w-5" data-testid="icon-course" />;
      case "mentor":
        return <User className="h-5 w-5" data-testid="icon-mentor" />;
      default:
        return <ExternalLink className="h-5 w-5" data-testid="icon-article" />;
    }
  };

  const getTypeBadgeColor = (type: string) => {
    switch (type) {
      case "book":
        return "bg-blue-100 text-blue-700 hover:bg-blue-200";
      case "course":
        return "bg-green-100 text-green-700 hover:bg-green-200";
      case "mentor":
        return "bg-purple-100 text-purple-700 hover:bg-purple-200";
      default:
        return "bg-gray-100 text-gray-700 hover:bg-gray-200";
    }
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={cn(
              "h-4 w-4",
              i < Math.floor(rating) 
                ? "text-gold-400 fill-gold-400" 
                : "text-gray-300"
            )}
            data-testid={`star-${i}`}
          />
        ))}
        <span className="ml-2 text-sm text-gray-600" data-testid="text-rating">
          {rating.toFixed(1)}
        </span>
      </div>
    );
  };

  const ResourceCard = ({ resource }: { resource: Resource }) => {
    const competency = competencies?.find(c => c.id === resource.competencyId);

    return (
      <Card 
        className="group hover:shadow-lg transition-all duration-300 cursor-pointer border border-gray-200 hover:border-executive-300"
        data-testid={`resource-card-${resource.id}`}
      >
        <div className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center space-x-3">
              {resource.imageUrl ? (
                <img
                  src={resource.imageUrl}
                  alt={resource.title}
                  className="w-12 h-12 object-cover rounded-lg"
                  data-testid={`img-resource-${resource.id}`}
                />
              ) : (
                <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                  {getTypeIcon(resource.type)}
                </div>
              )}
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 group-hover:text-executive-600 transition-colors" data-testid={`text-title-${resource.id}`}>
                  {resource.title}
                </h3>
                {resource.author && (
                  <p className="text-sm text-gray-600" data-testid={`text-author-${resource.id}`}>
                    by {resource.author}
                  </p>
                )}
              </div>
            </div>
            <Badge className={cn("text-xs", getTypeBadgeColor(resource.type))} data-testid={`badge-type-${resource.id}`}>
              {resource.type.charAt(0).toUpperCase() + resource.type.slice(1)}
            </Badge>
          </div>

          <p className="text-gray-700 text-sm mb-4 line-clamp-3" data-testid={`text-description-${resource.id}`}>
            {resource.description}
          </p>

          <div className="flex items-center justify-between">
            <div className="space-y-2">
              {resource.rating && renderStars(resource.rating)}
              {competency && (
                <Badge variant="outline" className="text-xs" data-testid={`badge-competency-${resource.id}`}>
                  {competency.name}
                </Badge>
              )}
            </div>
            
            {resource.url && (
              <Button 
                variant="outline" 
                size="sm"
                className="opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => window.open(resource.url, '_blank')}
                data-testid={`button-open-${resource.id}`}
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Open
              </Button>
            )}
          </div>
        </div>
      </Card>
    );
  };

  const ResourceListItem = ({ resource }: { resource: Resource }) => {
    const competency = competencies?.find(c => c.id === resource.competencyId);

    return (
      <Card className="mb-4 hover:shadow-md transition-shadow" data-testid={`resource-list-${resource.id}`}>
        <div className="p-4">
          <div className="flex items-center space-x-4">
            {resource.imageUrl ? (
              <img
                src={resource.imageUrl}
                alt={resource.title}
                className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                data-testid={`img-list-resource-${resource.id}`}
              />
            ) : (
              <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                {getTypeIcon(resource.type)}
              </div>
            )}
            
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-1" data-testid={`text-list-title-${resource.id}`}>
                    {resource.title}
                  </h3>
                  {resource.author && (
                    <p className="text-sm text-gray-600 mb-2" data-testid={`text-list-author-${resource.id}`}>
                      by {resource.author}
                    </p>
                  )}
                  <p className="text-gray-700 text-sm mb-2" data-testid={`text-list-description-${resource.id}`}>
                    {resource.description}
                  </p>
                  
                  <div className="flex items-center space-x-4">
                    {resource.rating && (
                      <div className="flex items-center" data-testid={`rating-list-${resource.id}`}>
                        {renderStars(resource.rating)}
                      </div>
                    )}
                    <Badge className={cn("text-xs", getTypeBadgeColor(resource.type))} data-testid={`badge-list-type-${resource.id}`}>
                      {resource.type.charAt(0).toUpperCase() + resource.type.slice(1)}
                    </Badge>
                    {competency && (
                      <Badge variant="outline" className="text-xs" data-testid={`badge-list-competency-${resource.id}`}>
                        {competency.name}
                      </Badge>
                    )}
                  </div>
                </div>
                
                {resource.url && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => window.open(resource.url, '_blank')}
                    data-testid={`button-list-open-${resource.id}`}
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Open
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </Card>
    );
  };

  if (resourcesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="loading-resources">
        <Loader2 className="h-8 w-8 animate-spin text-executive-600" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-resources-title">
          Learning Resources
        </h1>
        <p className="text-lg text-gray-600" data-testid="text-resources-subtitle">
          Curated resources to accelerate your sustainability leadership development
        </p>
      </div>

      {/* Filters and Search */}
      <Card className="p-6 mb-8" data-testid="card-filters">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 flex-1">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" data-testid="icon-search" />
              <Input
                placeholder="Search resources..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search"
              />
            </div>

            {/* Type Filter */}
            <Select value={selectedType} onValueChange={setSelectedType} data-testid="select-type">
              <SelectTrigger className="w-40">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="book">Books</SelectItem>
                <SelectItem value="course">Courses</SelectItem>
                <SelectItem value="mentor">Mentors</SelectItem>
                <SelectItem value="article">Articles</SelectItem>
              </SelectContent>
            </Select>

            {/* Competency Filter */}
            <Select value={selectedCompetency} onValueChange={setSelectedCompetency} data-testid="select-competency">
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Competencies" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Competencies</SelectItem>
                {competencies?.map(competency => (
                  <SelectItem key={competency.id} value={competency.id}>
                    {competency.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center space-x-2">
            <Button
              variant={viewMode === "grid" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("grid")}
              data-testid="button-grid-view"
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("list")}
              data-testid="button-list-view"
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>

      {/* Results Count */}
      <div className="mb-6">
        <p className="text-gray-600" data-testid="text-results-count">
          Showing {filteredResources.length} resources
          {searchQuery && ` for "${searchQuery}"`}
        </p>
      </div>

      {/* Resources Grid/List */}
      {filteredResources.length > 0 ? (
        <div className={cn(
          viewMode === "grid" 
            ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            : "space-y-4"
        )} data-testid="resources-container">
          {filteredResources.map((resource) => (
            viewMode === "grid" 
              ? <ResourceCard key={resource.id} resource={resource} />
              : <ResourceListItem key={resource.id} resource={resource} />
          ))}
        </div>
      ) : (
        <Card className="p-12 text-center" data-testid="empty-resources">
          <BookOpen className="mx-auto h-16 w-16 text-gray-400 mb-4" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">
            No resources found
          </h3>
          <p className="text-gray-600 max-w-md mx-auto">
            {searchQuery || selectedType !== "all" || selectedCompetency !== "all" 
              ? "Try adjusting your search or filters to find more resources."
              : "Resources will appear here as they become available."
            }
          </p>
          {(searchQuery || selectedType !== "all" || selectedCompetency !== "all") && (
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => {
                setSearchQuery("");
                setSelectedType("all");
                setSelectedCompetency("all");
              }}
              data-testid="button-clear-filters"
            >
              Clear Filters
            </Button>
          )}
        </Card>
      )}
    </div>
  );
}
