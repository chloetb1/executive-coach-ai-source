import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import ProgressOverview from "@/components/dashboard/progress-overview";
import CompetencyMatrix from "@/components/dashboard/competency-matrix";
import DevelopmentTimeline from "@/components/dashboard/development-timeline";
import QuickActions from "@/components/dashboard/quick-actions";
import ActionItems from "@/components/dashboard/action-items";
import type { DashboardData } from "@/lib/types";

export default function Dashboard() {
  const { data: dashboardData, isLoading, error } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard/user-1"], // Using default user for demo
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="loading-dashboard">
        <Loader2 className="h-8 w-8 animate-spin text-executive-600" />
      </div>
    );
  }

  if (error || !dashboardData) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="error-dashboard">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Unable to load dashboard</h2>
          <p className="text-gray-600">Please check your connection and try again.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome Section */}
      <div className="mb-8 animate-fade-in" data-testid="section-welcome">
        <div className="bg-gradient-to-r from-executive-600 to-executive-500 rounded-2xl p-8 text-white executive-shadow">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h2 className="text-3xl font-bold mb-2" data-testid="text-welcome-message">
                Welcome back, {dashboardData.user.name}
              </h2>
              <p className="text-executive-100 text-lg mb-4" data-testid="text-welcome-subtitle">
                Ready to accelerate your sustainability leadership journey?
              </p>
              <div className="flex items-center space-x-4">
                <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
                  <span className="text-sm font-medium" data-testid="text-current-level">
                    Current Level: {dashboardData.user.role.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </span>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
                  <span className="text-sm font-medium" data-testid="text-goal">
                    Goal: {dashboardData.user.goal.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </span>
                </div>
              </div>
            </div>
            <div className="hidden lg:block ml-8">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200" 
                alt="Professional executive portrait" 
                className="w-24 h-24 rounded-2xl object-cover border-4 border-white/30"
                data-testid="img-profile"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        {/* Progress Overview */}
        <div className="lg:col-span-2">
          <ProgressOverview competencies={dashboardData.competencies} />
        </div>
        
        {/* Quick Actions */}
        <div>
          <QuickActions />
        </div>
      </div>
      
      {/* Coaching and Competency */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <CompetencyMatrix 
          competencies={dashboardData.competencies}
          overallProgress={dashboardData.overallProgress}
        />
        
        <ActionItems actionItems={dashboardData.actionItems} />
      </div>
      
      {/* Development Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <DevelopmentTimeline 
            milestones={dashboardData.milestones}
            resources={dashboardData.resources}
          />
        </div>
        
        {/* Resources will be shown in the timeline component */}
      </div>
    </div>
  );
}
