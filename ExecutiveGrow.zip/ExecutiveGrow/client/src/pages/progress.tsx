import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, TrendingUp, Target, Award, Calendar } from "lucide-react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import type { DashboardData } from "@/lib/types";

export default function ProgressPage() {
  const { data: dashboardData, isLoading, error } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard/user-1"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="loading-progress">
        <Loader2 className="h-8 w-8 animate-spin text-executive-600" />
      </div>
    );
  }

  if (error || !dashboardData) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="error-progress">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Unable to load progress data</h2>
          <p className="text-gray-600">Please check your connection and try again.</p>
        </div>
      </div>
    );
  }

  // Generate mock historical data for visualization
  const historicalData = [
    { month: "Jan", strategic: 6.2, financial: 2.1, leadership: 5.8, stakeholder: 5.5 },
    { month: "Feb", strategic: 6.8, financial: 2.8, leadership: 6.0, stakeholder: 5.9 },
    { month: "Mar", strategic: 7.2, financial: 3.5, leadership: 6.2, stakeholder: 6.1 },
    { month: "Apr", strategic: 7.5, financial: 3.9, leadership: 6.3, stakeholder: 6.3 },
    { month: "May", strategic: 7.8, financial: 4.2, leadership: 6.5, stakeholder: 6.5 },
  ];

  const radarData = [
    { competency: "Strategic", current: dashboardData.overallProgress.strategic, target: 10 },
    { competency: "Financial", current: dashboardData.overallProgress.financial, target: 10 },
    { competency: "Leadership", current: dashboardData.overallProgress.leadership, target: 10 },
    { competency: "Stakeholder", current: dashboardData.overallProgress.stakeholder, target: 10 },
  ];

  const completedMilestones = dashboardData.milestones.filter(m => m.status === "completed").length;
  const totalMilestones = dashboardData.milestones.length;
  const completedActions = dashboardData.actionItems.filter(a => a.completed).length;
  const totalActions = dashboardData.actionItems.length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-progress-title">
          Progress Tracking
        </h1>
        <p className="text-lg text-gray-600" data-testid="text-progress-subtitle">
          Monitor your journey toward sustainability leadership excellence
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="p-6" data-testid="card-overall-progress">
          <div className="flex items-center">
            <TrendingUp className="h-8 w-8 text-executive-600 mr-3" data-testid="icon-trending" />
            <div>
              <p className="text-sm text-gray-600">Overall Progress</p>
              <p className="text-2xl font-bold text-gray-900" data-testid="text-overall-percentage">
                {Math.round(
                  (dashboardData.overallProgress.strategic + 
                   dashboardData.overallProgress.financial + 
                   dashboardData.overallProgress.leadership + 
                   dashboardData.overallProgress.stakeholder) / 4 * 10
                )}%
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6" data-testid="card-milestones">
          <div className="flex items-center">
            <Target className="h-8 w-8 text-green-600 mr-3" data-testid="icon-target" />
            <div>
              <p className="text-sm text-gray-600">Milestones</p>
              <p className="text-2xl font-bold text-gray-900" data-testid="text-milestones-count">
                {completedMilestones}/{totalMilestones}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6" data-testid="card-action-items">
          <div className="flex items-center">
            <Award className="h-8 w-8 text-gold-600 mr-3" data-testid="icon-award" />
            <div>
              <p className="text-sm text-gray-600">Action Items</p>
              <p className="text-2xl font-bold text-gray-900" data-testid="text-actions-count">
                {completedActions}/{totalActions}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6" data-testid="card-time-invested">
          <div className="flex items-center">
            <Calendar className="h-8 w-8 text-blue-600 mr-3" data-testid="icon-calendar" />
            <div>
              <p className="text-sm text-gray-600">Time Invested</p>
              <p className="text-2xl font-bold text-gray-900" data-testid="text-time-invested">
                24h
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Progress Over Time */}
        <Card className="p-6" data-testid="card-progress-chart">
          <h3 className="text-xl font-bold text-gray-900 mb-6" data-testid="text-chart-title">
            Progress Over Time
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={historicalData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis domain={[0, 10]} />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="strategic" 
                  stroke="hsl(210 86% 44%)" 
                  strokeWidth={2}
                  name="Strategic"
                  data-testid="line-strategic"
                />
                <Line 
                  type="monotone" 
                  dataKey="financial" 
                  stroke="hsl(43 89% 50%)" 
                  strokeWidth={2}
                  name="Financial"
                  data-testid="line-financial"
                />
                <Line 
                  type="monotone" 
                  dataKey="leadership" 
                  stroke="hsl(159 100% 36%)" 
                  strokeWidth={2}
                  name="Leadership"
                  data-testid="line-leadership"
                />
                <Line 
                  type="monotone" 
                  dataKey="stakeholder" 
                  stroke="hsl(203 88% 53%)" 
                  strokeWidth={2}
                  name="Stakeholder"
                  data-testid="line-stakeholder"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Competency Radar */}
        <Card className="p-6" data-testid="card-radar-chart">
          <h3 className="text-xl font-bold text-gray-900 mb-6" data-testid="text-radar-title">
            Competency Overview
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="competency" />
                <PolarRadiusAxis domain={[0, 10]} />
                <Radar 
                  name="Current Level" 
                  dataKey="current" 
                  stroke="hsl(210 86% 44%)" 
                  fill="hsl(210 86% 44%)" 
                  fillOpacity={0.3}
                  data-testid="radar-current"
                />
                <Radar 
                  name="Target Level" 
                  dataKey="target" 
                  stroke="hsl(43 89% 50%)" 
                  fill="hsl(43 89% 50%)" 
                  fillOpacity={0.1}
                  data-testid="radar-target"
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      {/* Detailed Competency Breakdown */}
      <Card className="p-6" data-testid="card-competency-breakdown">
        <h3 className="text-xl font-bold text-gray-900 mb-6" data-testid="text-breakdown-title">
          Competency Breakdown
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {dashboardData.competencies.map((competency) => (
            <div key={competency.id} className="space-y-3" data-testid={`competency-detail-${competency.id}`}>
              <div className="flex justify-between items-center">
                <h4 className="font-semibold text-gray-900" data-testid={`text-competency-name-${competency.id}`}>
                  {competency.name}
                </h4>
                <span className="text-sm text-gray-600" data-testid={`text-competency-level-${competency.id}`}>
                  {competency.currentLevel.toFixed(1)}/10
                </span>
              </div>
              <Progress value={competency.progress} className="h-2" data-testid={`progress-competency-${competency.id}`} />
              <div className="flex flex-wrap gap-1">
                {competency.skills.map((skill, index) => (
                  <span 
                    key={skill}
                    className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded"
                    data-testid={`skill-tag-${competency.id}-${index}`}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
