import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Send, Mic, Bot, User, CircleDot } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ChatMessage, CoachingSession, ChatResponse } from "@/lib/types";

export default function Coaching() {
  const [message, setMessage] = useState("");
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get coaching sessions
  const { data: sessions } = useQuery<CoachingSession[]>({
    queryKey: ["/api/coaching-sessions/user-1"],
  });

  // Get chat messages for current session
  const { data: messages, isLoading: messagesLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat-messages", currentSessionId],
    enabled: !!currentSessionId,
  });

  // Create new session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (title: string) => {
      return apiRequest("POST", "/api/coaching-sessions", {
        userId: "user-1",
        title,
        status: "active"
      });
    },
    onSuccess: async (response) => {
      const session = await response.json();
      setCurrentSessionId(session.id);
      queryClient.invalidateQueries({ queryKey: ["/api/coaching-sessions/user-1"] });
    },
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest("POST", "/api/chat-messages", {
        sessionId: currentSessionId,
        role: "user",
        content
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat-messages", currentSessionId] });
      setMessage("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStartNewSession = () => {
    const sessionTitle = `Coaching Session - ${new Date().toLocaleDateString()}`;
    createSessionMutation.mutate(sessionTitle);
  };

  const handleSendMessage = () => {
    if (!message.trim() || !currentSessionId) return;
    sendMessageMutation.mutate(message);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-coaching-title">
          AI Executive Coaching
        </h1>
        <p className="text-lg text-gray-600" data-testid="text-coaching-subtitle">
          Accelerate your sustainability leadership development with personalized coaching
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Session List */}
        <div className="lg:col-span-1">
          <Card className="p-6" data-testid="card-sessions">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900" data-testid="text-sessions-title">
                Sessions
              </h3>
              <Button 
                onClick={handleStartNewSession}
                disabled={createSessionMutation.isPending}
                size="sm"
                data-testid="button-new-session"
              >
                {createSessionMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  "New"
                )}
              </Button>
            </div>
            
            <div className="space-y-2">
              {sessions?.map((session) => (
                <button
                  key={session.id}
                  onClick={() => setCurrentSessionId(session.id)}
                  className={`w-full text-left p-3 rounded-lg transition-colors ${
                    currentSessionId === session.id 
                      ? "bg-executive-100 text-executive-900 border border-executive-200" 
                      : "hover:bg-gray-50"
                  }`}
                  data-testid={`session-${session.id}`}
                >
                  <div className="font-medium text-sm truncate" data-testid={`text-session-title-${session.id}`}>
                    {session.title}
                  </div>
                  <div className="text-xs text-gray-500" data-testid={`text-session-date-${session.id}`}>
                    {new Date(session.createdAt).toLocaleDateString()}
                  </div>
                </button>
              )) || (
                <div className="text-sm text-gray-500 text-center py-4" data-testid="text-no-sessions">
                  No sessions yet. Start your first coaching session!
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Chat Interface */}
        <div className="lg:col-span-3">
          <Card className="p-6 h-[600px] flex flex-col" data-testid="card-chat">
            {currentSessionId ? (
              <>
                {/* Chat Header */}
                <div className="flex items-center justify-between mb-6 pb-4 border-b">
                  <h3 className="text-xl font-bold text-gray-900" data-testid="text-chat-title">
                    AI Executive Coach
                  </h3>
                  <div className="flex items-center space-x-2">
                    <CircleDot className="w-2 h-2 text-green-400 animate-pulse" data-testid="icon-active" />
                    <span className="text-sm text-gray-600" data-testid="text-session-status">
                      Active Session
                    </span>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto space-y-4 mb-6" data-testid="chat-messages">
                  {messagesLoading ? (
                    <div className="flex items-center justify-center h-full" data-testid="loading-messages">
                      <Loader2 className="h-8 w-8 animate-spin text-executive-600" />
                    </div>
                  ) : messages?.length ? (
                    messages.map((msg) => (
                      <div 
                        key={msg.id}
                        className={`flex items-start space-x-3 chat-bubble ${
                          msg.role === "assistant" ? "" : "justify-end"
                        }`}
                        data-testid={`message-${msg.id}`}
                      >
                        {msg.role === "assistant" && (
                          <div className="w-8 h-8 bg-gradient-to-r from-executive-600 to-executive-500 rounded-full flex items-center justify-center flex-shrink-0">
                            <Bot className="text-white" size={16} data-testid="icon-bot" />
                          </div>
                        )}
                        <div className={`rounded-2xl p-4 max-w-xs lg:max-w-md ${
                          msg.role === "assistant" 
                            ? "bg-gray-50 rounded-tl-sm" 
                            : "bg-executive-600 text-white rounded-tr-sm"
                        }`}>
                          <p className={msg.role === "assistant" ? "text-gray-800" : "text-white"} data-testid={`text-message-content-${msg.id}`}>
                            {msg.content}
                          </p>
                        </div>
                        {msg.role === "user" && (
                          <div className="w-8 h-8 bg-gradient-to-r from-gold-500 to-gold-400 rounded-full flex items-center justify-center flex-shrink-0">
                            <User className="text-white" size={16} data-testid="icon-user" />
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center" data-testid="empty-chat">
                        <Bot className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">
                          Ready to begin coaching?
                        </h3>
                        <p className="text-gray-600 mb-4">
                          Start by sharing a challenge you're facing or ask about developing a specific leadership competency.
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Message Input */}
                <div className="flex items-center space-x-3" data-testid="message-input-container">
                  <div className="flex-1 relative">
                    <Input
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Share your thoughts or ask a question..."
                      className="pr-12 h-12"
                      disabled={sendMessageMutation.isPending}
                      data-testid="input-message"
                    />
                    <Button
                      onClick={handleSendMessage}
                      disabled={!message.trim() || sendMessageMutation.isPending}
                      size="sm"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                      data-testid="button-send"
                    >
                      {sendMessageMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-12 w-12 p-0"
                    data-testid="button-mic"
                  >
                    <Mic className="h-4 w-4" />
                  </Button>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center" data-testid="no-session-selected">
                  <Bot className="mx-auto h-16 w-16 text-gray-400 mb-4" />
                  <h3 className="text-xl font-medium text-gray-900 mb-2">
                    Welcome to Executive Coaching
                  </h3>
                  <p className="text-gray-600 mb-6 max-w-md">
                    Start a new coaching session to begin developing your sustainability leadership skills with AI-powered guidance.
                  </p>
                  <Button onClick={handleStartNewSession} data-testid="button-start-coaching">
                    Start Coaching Session
                  </Button>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
