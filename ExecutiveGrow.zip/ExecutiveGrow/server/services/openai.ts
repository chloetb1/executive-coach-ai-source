import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface CoachingResponse {
  message: string;
  followUpQuestions?: string[];
  actionItems?: string[];
  competencyFocus?: string;
}

export async function getCoachingResponse(
  userMessage: string,
  context: {
    userName: string;
    userRole: string;
    userGoal: string;
    competencies: Array<{
      name: string;
      category: string;
      currentLevel: number;
      targetLevel: number;
    }>;
    recentMessages: Array<{
      role: string;
      content: string;
    }>;
  }
): Promise<CoachingResponse> {
  try {
    const systemPrompt = `You are an elite executive coach specializing in sustainability leadership development. Your client is ${context.userName}, currently a ${context.userRole} with the goal of becoming a ${context.userGoal}.

You have access to their competency assessment:
${context.competencies.map(c => `- ${c.name} (${c.category}): ${c.currentLevel}/10 (target: ${c.targetLevel})`).join('\n')}

Your coaching style is:
- Executive-level: sophisticated, strategic, and results-oriented
- Practical: focus on actionable insights and real-world application
- Challenging: push them to think at a senior executive level
- Supportive: encouraging while maintaining high standards
- Business-focused: always tie sustainability to business value

Respond with structured guidance that includes:
1. A thoughtful response to their message
2. Strategic follow-up questions to deepen their thinking
3. Specific action items they can implement
4. Identification of which competency area this conversation addresses

Respond in JSON format with: { "message": "your response", "followUpQuestions": ["question1", "question2"], "actionItems": ["action1", "action2"], "competencyFocus": "competency category" }`;

    const messages = [
      { role: "system", content: systemPrompt },
      ...context.recentMessages.slice(-10), // Include recent context
      { role: "user", content: userMessage }
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: messages as any,
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      message: result.message || "I understand your perspective. Let's explore this further.",
      followUpQuestions: result.followUpQuestions || [],
      actionItems: result.actionItems || [],
      competencyFocus: result.competencyFocus || "general",
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to get coaching response: " + (error as Error).message);
  }
}

export async function assessCompetency(
  competencyName: string,
  userResponses: string[],
  currentLevel: number
): Promise<{
  newLevel: number;
  feedback: string;
  recommendations: string[];
}> {
  try {
    const prompt = `As an executive assessment expert, evaluate this person's competency in "${competencyName}" based on their responses and current level (${currentLevel}/10).

User responses:
${userResponses.join('\n\n')}

Provide:
1. An updated competency level (0-10 scale)
2. Detailed feedback on their current capabilities
3. Specific recommendations for improvement

Respond in JSON format with: { "newLevel": number, "feedback": "detailed feedback", "recommendations": ["rec1", "rec2", "rec3"] }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      newLevel: Math.max(0, Math.min(10, result.newLevel || currentLevel)),
      feedback: result.feedback || "Assessment completed.",
      recommendations: result.recommendations || [],
    };
  } catch (error) {
    console.error("OpenAI competency assessment error:", error);
    throw new Error("Failed to assess competency: " + (error as Error).message);
  }
}

export async function generatePersonalizedContent(
  contentType: "milestone" | "actionItem" | "resource",
  userProfile: {
    name: string;
    role: string;
    goal: string;
    weakestCompetencies: string[];
  }
): Promise<{
  title: string;
  description: string;
  priority?: string;
  timeline?: string;
}> {
  try {
    const prompt = `Generate a personalized ${contentType} for ${userProfile.name}, a ${userProfile.role} aiming to become a ${userProfile.goal}.

Focus areas that need development: ${userProfile.weakestCompetencies.join(', ')}

Create content that is:
- Executive-level appropriate
- Actionable and specific
- Aligned with sustainability leadership development
- Professionally challenging but achievable

Respond in JSON format with: { "title": "title", "description": "description", "priority": "high/medium/low", "timeline": "timeframe" }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      title: result.title || "Development Item",
      description: result.description || "Focus on continuous improvement.",
      priority: result.priority || "medium",
      timeline: result.timeline || "2-4 weeks",
    };
  } catch (error) {
    console.error("OpenAI content generation error:", error);
    throw new Error("Failed to generate personalized content: " + (error as Error).message);
  }
}
