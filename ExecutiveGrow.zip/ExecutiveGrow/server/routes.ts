import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertChatMessageSchema, 
  insertCoachingSessionSchema,
  insertActionItemSchema,
  insertMilestoneSchema 
} from "@shared/schema";
import { getCoachingResponse, assessCompetency, generatePersonalizedContent } from "./services/openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Users
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  // Dashboard data
  app.get("/api/dashboard/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      
      const [user, competencies, userCompetencies, milestones, actionItems, resources] = await Promise.all([
        storage.getUser(userId),
        storage.getCompetencies(),
        storage.getUserCompetencies(userId),
        storage.getMilestones(userId),
        storage.getActionItems(userId),
        storage.getResources()
      ]);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Combine competencies with user progress
      const competencyProgress = competencies.map(comp => {
        const userComp = userCompetencies.find(uc => uc.competencyId === comp.id);
        return {
          ...comp,
          currentLevel: userComp?.currentLevel || 0,
          targetLevel: userComp?.targetLevel || 10,
          progress: ((userComp?.currentLevel || 0) / (userComp?.targetLevel || 10)) * 100
        };
      });

      res.json({
        user,
        competencies: competencyProgress,
        milestones,
        actionItems,
        resources: resources.slice(0, 3), // Top 3 recommended resources
        overallProgress: {
          strategic: competencyProgress.find(c => c.category === 'strategic')?.currentLevel || 0,
          financial: competencyProgress.find(c => c.category === 'financial')?.currentLevel || 0,
          leadership: competencyProgress.find(c => c.category === 'leadership')?.currentLevel || 0,
          stakeholder: competencyProgress.find(c => c.category === 'stakeholder')?.currentLevel || 0
        }
      });
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  // Coaching Sessions
  app.get("/api/coaching-sessions/:userId", async (req, res) => {
    try {
      const sessions = await storage.getCoachingSessions(req.params.userId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/coaching-sessions", async (req, res) => {
    try {
      const validatedData = insertCoachingSessionSchema.parse(req.body);
      const session = await storage.createCoachingSession(validatedData);
      res.status(201).json(session);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Chat Messages
  app.get("/api/chat-messages/:sessionId", async (req, res) => {
    try {
      const messages = await storage.getChatMessages(req.params.sessionId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/chat-messages", async (req, res) => {
    try {
      const validatedData = insertChatMessageSchema.parse(req.body);
      
      // Save user message
      const userMessage = await storage.createChatMessage(validatedData);
      
      if (validatedData.role === "user") {
        // Get user context for AI response
        const session = await storage.getCoachingSession(validatedData.sessionId);
        if (!session) {
          return res.status(404).json({ message: "Session not found" });
        }

        const user = await storage.getUser(session.userId);
        const competencies = await storage.getCompetencies();
        const userCompetencies = await storage.getUserCompetencies(session.userId);
        const recentMessages = await storage.getChatMessages(validatedData.sessionId);

        const context = {
          userName: user?.name || "User",
          userRole: user?.role || "sustainability-consultant",
          userGoal: user?.goal || "senior-executive",
          competencies: competencies.map(comp => {
            const userComp = userCompetencies.find(uc => uc.competencyId === comp.id);
            return {
              name: comp.name,
              category: comp.category,
              currentLevel: userComp?.currentLevel || 0,
              targetLevel: userComp?.targetLevel || 10
            };
          }),
          recentMessages: recentMessages.slice(-10).map(msg => ({
            role: msg.role,
            content: msg.content
          }))
        };

        // Get AI response
        const coachingResponse = await getCoachingResponse(validatedData.content, context);
        
        // Save AI response
        const aiMessage = await storage.createChatMessage({
          sessionId: validatedData.sessionId,
          role: "assistant",
          content: coachingResponse.message
        });

        // Create action items if suggested
        if (coachingResponse.actionItems && coachingResponse.actionItems.length > 0) {
          for (const actionTitle of coachingResponse.actionItems) {
            await storage.createActionItem({
              userId: session.userId,
              title: actionTitle,
              priority: "medium",
              dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 1 week from now
            });
          }
        }

        res.json({
          userMessage,
          aiMessage,
          followUpQuestions: coachingResponse.followUpQuestions,
          actionItems: coachingResponse.actionItems,
          competencyFocus: coachingResponse.competencyFocus
        });
      } else {
        res.json(userMessage);
      }
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Competencies
  app.get("/api/competencies", async (req, res) => {
    try {
      const competencies = await storage.getCompetencies();
      res.json(competencies);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.get("/api/user-competencies/:userId", async (req, res) => {
    try {
      const userCompetencies = await storage.getUserCompetencies(req.params.userId);
      const competencies = await storage.getCompetencies();
      
      const result = competencies.map(comp => {
        const userComp = userCompetencies.find(uc => uc.competencyId === comp.id);
        return {
          ...comp,
          currentLevel: userComp?.currentLevel || 0,
          targetLevel: userComp?.targetLevel || 10,
          lastAssessed: userComp?.lastAssessed || null
        };
      });

      res.json(result);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  // Milestones
  app.get("/api/milestones/:userId", async (req, res) => {
    try {
      const milestones = await storage.getMilestones(req.params.userId);
      res.json(milestones);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/milestones", async (req, res) => {
    try {
      const validatedData = insertMilestoneSchema.parse(req.body);
      const milestone = await storage.createMilestone(validatedData);
      res.status(201).json(milestone);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  app.patch("/api/milestones/:id", async (req, res) => {
    try {
      const milestone = await storage.updateMilestone(req.params.id, req.body);
      res.json(milestone);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Action Items
  app.get("/api/action-items/:userId", async (req, res) => {
    try {
      const actionItems = await storage.getActionItems(req.params.userId);
      res.json(actionItems);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/action-items", async (req, res) => {
    try {
      const validatedData = insertActionItemSchema.parse(req.body);
      const actionItem = await storage.createActionItem(validatedData);
      res.status(201).json(actionItem);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  app.patch("/api/action-items/:id", async (req, res) => {
    try {
      const actionItem = await storage.updateActionItem(req.params.id, req.body);
      res.json(actionItem);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Resources
  app.get("/api/resources", async (req, res) => {
    try {
      const competencyId = req.query.competencyId as string;
      const resources = await storage.getResources(competencyId);
      res.json(resources);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  // AI-powered content generation
  app.post("/api/generate-content", async (req, res) => {
    try {
      const { userId, contentType } = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const userCompetencies = await storage.getUserCompetencies(userId);
      const competencies = await storage.getCompetencies();
      
      // Find weakest competencies
      const competencyLevels = competencies.map(comp => {
        const userComp = userCompetencies.find(uc => uc.competencyId === comp.id);
        return {
          name: comp.name,
          level: userComp?.currentLevel || 0
        };
      }).sort((a, b) => a.level - b.level);

      const weakestCompetencies = competencyLevels.slice(0, 2).map(c => c.name);

      const content = await generatePersonalizedContent(contentType, {
        name: user.name,
        role: user.role,
        goal: user.goal,
        weakestCompetencies
      });

      res.json(content);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
