import { 
  type User, type InsertUser,
  type Competency, type InsertCompetency,
  type UserCompetency, type InsertUserCompetency,
  type CoachingSession, type InsertCoachingSession,
  type ChatMessage, type InsertChatMessage,
  type Milestone, type InsertMilestone,
  type ActionItem, type InsertActionItem,
  type Resource, type InsertResource
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;

  // Competencies
  getCompetencies(): Promise<Competency[]>;
  getCompetency(id: string): Promise<Competency | undefined>;
  createCompetency(competency: InsertCompetency): Promise<Competency>;

  // User Competencies
  getUserCompetencies(userId: string): Promise<UserCompetency[]>;
  getUserCompetency(userId: string, competencyId: string): Promise<UserCompetency | undefined>;
  createUserCompetency(userCompetency: InsertUserCompetency): Promise<UserCompetency>;
  updateUserCompetency(userId: string, competencyId: string, updates: Partial<UserCompetency>): Promise<UserCompetency>;

  // Coaching Sessions
  getCoachingSessions(userId: string): Promise<CoachingSession[]>;
  getCoachingSession(id: string): Promise<CoachingSession | undefined>;
  createCoachingSession(session: InsertCoachingSession): Promise<CoachingSession>;
  updateCoachingSession(id: string, updates: Partial<CoachingSession>): Promise<CoachingSession>;

  // Chat Messages
  getChatMessages(sessionId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;

  // Milestones
  getMilestones(userId: string): Promise<Milestone[]>;
  createMilestone(milestone: InsertMilestone): Promise<Milestone>;
  updateMilestone(id: string, updates: Partial<Milestone>): Promise<Milestone>;

  // Action Items
  getActionItems(userId: string): Promise<ActionItem[]>;
  createActionItem(actionItem: InsertActionItem): Promise<ActionItem>;
  updateActionItem(id: string, updates: Partial<ActionItem>): Promise<ActionItem>;

  // Resources
  getResources(competencyId?: string): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private competencies: Map<string, Competency> = new Map();
  private userCompetencies: Map<string, UserCompetency> = new Map();
  private coachingSessions: Map<string, CoachingSession> = new Map();
  private chatMessages: Map<string, ChatMessage> = new Map();
  private milestones: Map<string, Milestone> = new Map();
  private actionItems: Map<string, ActionItem> = new Map();
  private resources: Map<string, Resource> = new Map();

  constructor() {
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Create default competencies
    const defaultCompetencies: Competency[] = [
      {
        id: "comp-1",
        name: "Strategic Thinking",
        category: "strategic",
        description: "Developing systems thinking for complex sustainability challenges",
        skills: ["Vision Setting", "Systems Thinking", "Innovation Management"]
      },
      {
        id: "comp-2",
        name: "Financial Acumen",
        category: "financial",
        description: "Business case development for sustainability initiatives",
        skills: ["P&L Management", "ROI Analysis", "Budget Planning"]
      },
      {
        id: "comp-3",
        name: "Leadership",
        category: "leadership",
        description: "Building influence across organizational levels",
        skills: ["Team Building", "Change Management", "Executive Presence"]
      },
      {
        id: "comp-4",
        name: "Stakeholder Management",
        category: "stakeholder",
        description: "Navigate complex stakeholder ecosystems",
        skills: ["Board Communication", "Investor Relations", "Public Speaking"]
      }
    ];

    defaultCompetencies.forEach(comp => this.competencies.set(comp.id, comp));

    // Create default user
    const defaultUser: User = {
      id: "user-1",
      username: "sarah",
      email: "sarah@example.com",
      name: "Sarah Chen",
      role: "sustainability-consultant",
      goal: "senior-executive",
      createdAt: new Date()
    };
    this.users.set(defaultUser.id, defaultUser);

    // Create default user competencies
    const userComps: UserCompetency[] = [
      { id: "uc-1", userId: "user-1", competencyId: "comp-1", currentLevel: 7.8, targetLevel: 10, lastAssessed: new Date() },
      { id: "uc-2", userId: "user-1", competencyId: "comp-2", currentLevel: 4.2, targetLevel: 10, lastAssessed: new Date() },
      { id: "uc-3", userId: "user-1", competencyId: "comp-3", currentLevel: 6.5, targetLevel: 10, lastAssessed: new Date() },
      { id: "uc-4", userId: "user-1", competencyId: "comp-4", currentLevel: 6.5, targetLevel: 10, lastAssessed: new Date() }
    ];
    userComps.forEach(uc => this.userCompetencies.set(uc.id, uc));

    // Create default milestones
    const defaultMilestones: Milestone[] = [
      {
        id: "milestone-1",
        userId: "user-1",
        title: "Foundation Assessment Complete",
        description: "Comprehensive baseline evaluation of current sustainability expertise and leadership capabilities.",
        status: "completed",
        progress: 100,
        targetDate: new Date('2024-01-15'),
        completedAt: new Date('2024-01-15'),
        order: 1
      },
      {
        id: "milestone-2",
        userId: "user-1",
        title: "Financial Acumen Development",
        description: "Master business case development, ROI analysis, and P&L fundamentals for sustainability initiatives.",
        status: "in-progress",
        progress: 60,
        targetDate: new Date('2024-03-30'),
        completedAt: null,
        order: 2
      },
      {
        id: "milestone-3",
        userId: "user-1",
        title: "Executive Presence Mastery",
        description: "Develop commanding boardroom presence, strategic communication skills, and influential leadership style.",
        status: "pending",
        progress: 0,
        targetDate: new Date('2024-06-15'),
        completedAt: null,
        order: 3
      }
    ];
    defaultMilestones.forEach(m => this.milestones.set(m.id, m));

    // Create default action items
    const defaultActionItems: ActionItem[] = [
      {
        id: "action-1",
        userId: "user-1",
        title: "Complete ROI analysis for energy efficiency project",
        description: "Develop comprehensive financial model showing 3-year return on investment",
        completed: false,
        priority: "high",
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        createdAt: new Date()
      },
      {
        id: "action-2",
        userId: "user-1",
        title: "Schedule 1:1 with CFO to discuss sustainability metrics",
        description: "Present initial findings and align on key performance indicators",
        completed: true,
        priority: "high",
        dueDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        createdAt: new Date()
      },
      {
        id: "action-3",
        userId: "user-1",
        title: "Prepare executive summary for board presentation",
        description: "Create compelling one-page summary of sustainability initiative impact",
        completed: false,
        priority: "medium",
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
        createdAt: new Date()
      }
    ];
    defaultActionItems.forEach(a => this.actionItems.set(a.id, a));

    // Create default resources
    const defaultResources: Resource[] = [
      {
        id: "resource-1",
        title: "Sustainable Leadership",
        type: "book",
        description: "Strategic Framework for C-Suite",
        url: "https://example.com/book",
        author: "Dr. Michael Porter",
        rating: 4.8,
        competencyId: "comp-1",
        imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&h=80&fit=crop"
      },
      {
        id: "resource-2",
        title: "Executive Finance for Non-Finance Leaders",
        type: "course",
        description: "Harvard Business School Online - 8 weeks",
        url: "https://hbs.edu/executive-finance",
        author: "Harvard Business School",
        rating: 4.9,
        competencyId: "comp-2",
        imageUrl: null
      },
      {
        id: "resource-3",
        title: "Connect with Michael Chen",
        type: "mentor",
        description: "Chief Sustainability Officer, Fortune 500 - Available for Mentoring",
        url: null,
        author: "Michael Chen",
        rating: 5.0,
        competencyId: "comp-3",
        imageUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=50&h=50&fit=crop"
      }
    ];
    defaultResources.forEach(r => this.resources.set(r.id, r));
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      role: insertUser.role || "sustainability-consultant",
      goal: insertUser.goal || "senior-executive"
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) throw new Error('User not found');
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Competency methods
  async getCompetencies(): Promise<Competency[]> {
    return Array.from(this.competencies.values());
  }

  async getCompetency(id: string): Promise<Competency | undefined> {
    return this.competencies.get(id);
  }

  async createCompetency(insertCompetency: InsertCompetency): Promise<Competency> {
    const id = randomUUID();
    const competency: Competency = { 
      ...insertCompetency, 
      id,
      skills: Array.isArray(insertCompetency.skills) ? insertCompetency.skills : []
    };
    this.competencies.set(id, competency);
    return competency;
  }

  // User Competency methods
  async getUserCompetencies(userId: string): Promise<UserCompetency[]> {
    return Array.from(this.userCompetencies.values()).filter(uc => uc.userId === userId);
  }

  async getUserCompetency(userId: string, competencyId: string): Promise<UserCompetency | undefined> {
    return Array.from(this.userCompetencies.values()).find(
      uc => uc.userId === userId && uc.competencyId === competencyId
    );
  }

  async createUserCompetency(insertUserCompetency: InsertUserCompetency): Promise<UserCompetency> {
    const id = randomUUID();
    const userCompetency: UserCompetency = { 
      ...insertUserCompetency, 
      id, 
      lastAssessed: new Date(),
      currentLevel: insertUserCompetency.currentLevel || 0,
      targetLevel: insertUserCompetency.targetLevel || 10
    };
    this.userCompetencies.set(id, userCompetency);
    return userCompetency;
  }

  async updateUserCompetency(userId: string, competencyId: string, updates: Partial<UserCompetency>): Promise<UserCompetency> {
    const existing = await this.getUserCompetency(userId, competencyId);
    if (!existing) throw new Error('User competency not found');
    const updated = { ...existing, ...updates, lastAssessed: new Date() };
    this.userCompetencies.set(existing.id, updated);
    return updated;
  }

  // Coaching Session methods
  async getCoachingSessions(userId: string): Promise<CoachingSession[]> {
    return Array.from(this.coachingSessions.values()).filter(cs => cs.userId === userId);
  }

  async getCoachingSession(id: string): Promise<CoachingSession | undefined> {
    return this.coachingSessions.get(id);
  }

  async createCoachingSession(insertSession: InsertCoachingSession): Promise<CoachingSession> {
    const id = randomUUID();
    const session: CoachingSession = { 
      ...insertSession, 
      id, 
      createdAt: new Date(),
      updatedAt: new Date(),
      status: insertSession.status || "active"
    };
    this.coachingSessions.set(id, session);
    return session;
  }

  async updateCoachingSession(id: string, updates: Partial<CoachingSession>): Promise<CoachingSession> {
    const session = this.coachingSessions.get(id);
    if (!session) throw new Error('Coaching session not found');
    const updated = { ...session, ...updates, updatedAt: new Date() };
    this.coachingSessions.set(id, updated);
    return updated;
  }

  // Chat Message methods
  async getChatMessages(sessionId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(msg => msg.sessionId === sessionId)
      .sort((a, b) => {
        const aTime = a.createdAt ? a.createdAt.getTime() : 0;
        const bTime = b.createdAt ? b.createdAt.getTime() : 0;
        return aTime - bTime;
      });
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = { ...insertMessage, id, createdAt: new Date() };
    this.chatMessages.set(id, message);
    return message;
  }

  // Milestone methods
  async getMilestones(userId: string): Promise<Milestone[]> {
    return Array.from(this.milestones.values())
      .filter(m => m.userId === userId)
      .sort((a, b) => a.order - b.order);
  }

  async createMilestone(insertMilestone: InsertMilestone): Promise<Milestone> {
    const id = randomUUID();
    const milestone: Milestone = { 
      ...insertMilestone, 
      id,
      progress: insertMilestone.progress || 0,
      order: insertMilestone.order || 0,
      status: insertMilestone.status || "pending",
      targetDate: insertMilestone.targetDate || null,
      completedAt: null
    };
    this.milestones.set(id, milestone);
    return milestone;
  }

  async updateMilestone(id: string, updates: Partial<Milestone>): Promise<Milestone> {
    const milestone = this.milestones.get(id);
    if (!milestone) throw new Error('Milestone not found');
    const updated = { ...milestone, ...updates };
    if (updates.status === 'completed' && !milestone.completedAt) {
      updated.completedAt = new Date();
      updated.progress = 100;
    }
    this.milestones.set(id, updated);
    return updated;
  }

  // Action Item methods
  async getActionItems(userId: string): Promise<ActionItem[]> {
    return Array.from(this.actionItems.values())
      .filter(ai => ai.userId === userId)
      .sort((a, b) => {
        const aTime = a.createdAt ? a.createdAt.getTime() : 0;
        const bTime = b.createdAt ? b.createdAt.getTime() : 0;
        return aTime - bTime;
      });
  }

  async createActionItem(insertActionItem: InsertActionItem): Promise<ActionItem> {
    const id = randomUUID();
    const actionItem: ActionItem = { 
      ...insertActionItem, 
      id, 
      createdAt: new Date(),
      description: insertActionItem.description || null,
      completed: insertActionItem.completed || false,
      priority: insertActionItem.priority || "medium",
      dueDate: insertActionItem.dueDate || null
    };
    this.actionItems.set(id, actionItem);
    return actionItem;
  }

  async updateActionItem(id: string, updates: Partial<ActionItem>): Promise<ActionItem> {
    const actionItem = this.actionItems.get(id);
    if (!actionItem) throw new Error('Action item not found');
    const updated = { ...actionItem, ...updates };
    this.actionItems.set(id, updated);
    return updated;
  }

  // Resource methods
  async getResources(competencyId?: string): Promise<Resource[]> {
    const resources = Array.from(this.resources.values());
    if (competencyId) {
      return resources.filter(r => r.competencyId === competencyId);
    }
    return resources;
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = randomUUID();
    const resource: Resource = { 
      ...insertResource, 
      id,
      url: insertResource.url || null,
      competencyId: insertResource.competencyId || null,
      author: insertResource.author || null,
      rating: insertResource.rating || null,
      imageUrl: insertResource.imageUrl || null
    };
    this.resources.set(id, resource);
    return resource;
  }
}

export const storage = new MemStorage();
