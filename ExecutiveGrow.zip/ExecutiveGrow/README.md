# Executive Coach AI - Sustainability Leadership Development

A beautifully designed AI-powered executive coaching app for sustainability leadership development.

## Features

- 🎯 **Smart Dashboard** - Competency tracking with progress visualization
- 🤖 **AI Coaching** - Personalized coaching powered by GPT-4o
- 📊 **Progress Tracking** - Charts, milestones, and development roadmap
- 📚 **Learning Resources** - Curated materials for sustainability leadership
- ✅ **Action Items** - AI-generated development tasks
- 🎨 **Premium UX** - Executive-grade design with modern animations

## Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Backend**: Node.js + Express
- **UI**: Tailwind CSS + Shadcn/ui
- **AI**: OpenAI GPT-4o
- **Data**: In-memory storage with full CRUD operations

## Deploy to Vercel (Free)

1. Fork this repository or download the code
2. Connect to Vercel and import your repository
3. Add your `OPENAI_API_KEY` to Vercel environment variables
4. Deploy!

## Environment Variables

```env
OPENAI_API_KEY=your_openai_api_key_here
```

## Local Development

```bash
npm install
npm run dev
```

## User Journey

The app helps sustainability consultants develop into senior executives through:

1. **Assessment** - Baseline competency evaluation
2. **Coaching** - AI-powered conversations and guidance  
3. **Development** - Structured milestones and action items
4. **Resources** - Curated learning materials
5. **Tracking** - Progress visualization and analytics

Perfect for sustainability professionals aiming for C-suite roles!