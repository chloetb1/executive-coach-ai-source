# Deploy to Vercel (Free)

Your AI Executive Coaching app is ready for free deployment on Vercel! Follow these simple steps:

## Prerequisites

1. **GitHub Account** - Create one at github.com if you don't have it
2. **Vercel Account** - Sign up at vercel.com (free plan is perfect)
3. **OpenAI API Key** - Get yours at platform.openai.com

## Step 1: Upload Your Code

1. Download all your project files from Replit
2. Create a new repository on GitHub
3. Upload all files to your GitHub repository

## Step 2: Deploy to Vercel

1. Go to vercel.com and sign in
2. Click "New Project"
3. Import your GitHub repository
4. Vercel will automatically detect it's a Vite project
5. **Important**: Add Environment Variable:
   - Name: `OPENAI_API_KEY`
   - Value: Your OpenAI API key
6. Click "Deploy"

## Step 3: You're Live!

- Your app will be available at `yourproject.vercel.app`
- Free forever for personal use
- Automatic HTTPS and global CDN
- Automatic deployments when you update GitHub

## App Features

✅ **AI Coaching** - Personalized sustainability leadership guidance  
✅ **Progress Tracking** - Competency development charts  
✅ **Action Items** - AI-generated development tasks  
✅ **Resources Library** - Curated learning materials  
✅ **Executive Dashboard** - Beautiful progress visualization  

## Cost Breakdown

- **Vercel Hosting**: Free forever
- **OpenAI API**: ~$1-5/month for personal use
- **Total**: Practically free for personal coaching app

Your professional AI executive coaching platform is ready to help you advance from sustainability consultant to senior executive!