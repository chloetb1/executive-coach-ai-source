# Executive Coach AI - Sustainability Leadership Development Platform

## Overview

Executive Coach AI is a comprehensive sustainability leadership development platform that combines AI-powered coaching with competency tracking and personalized learning resources. The application helps sustainability professionals advance their careers from consultant level to senior executive positions through structured development programs, real-time coaching conversations, and progress tracking across key competency areas including strategic thinking, financial acumen, leadership skills, and stakeholder management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Framework**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom executive theme variables and sophisticated design system
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation schemas

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API architecture with structured route handlers
- **Development Setup**: Hot reload with Vite integration for seamless development experience
- **Error Handling**: Centralized error middleware with structured error responses

### Database Architecture
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL with Neon serverless database provider
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Data Modeling**: Comprehensive schema covering users, competencies, coaching sessions, chat messages, milestones, action items, and resources

### Authentication & Session Management
- **Session Storage**: PostgreSQL-based session storage using connect-pg-simple
- **User Management**: User profiles with role-based access and goal tracking
- **Security**: Session-based authentication with secure cookie handling

### AI Integration
- **LLM Provider**: OpenAI GPT-4o integration for conversational coaching
- **Coaching Features**: Personalized coaching responses, competency assessment, and content generation
- **Context Management**: Maintains conversation context and user competency data for personalized interactions

### Data Structure
- **Users**: Profile management with roles (sustainability-consultant) and goals (senior-executive)
- **Competencies**: Four main categories - strategic, financial, leadership, and stakeholder management
- **Progress Tracking**: User competency levels with current/target scoring on 0-10 scale
- **Coaching Sessions**: Structured conversation management with chat message history
- **Development Planning**: Milestones and action items for structured career progression
- **Resources**: Curated learning materials including books, courses, articles, and mentorship opportunities

### UI/UX Design Patterns
- **Design System**: Executive-focused theme with professional color palette and typography
- **Component Architecture**: Modular component structure with reusable UI primitives
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Animation**: Smooth transitions and micro-interactions for enhanced user experience
- **Accessibility**: WCAG-compliant components with proper ARIA labels and keyboard navigation

## External Dependencies

### Core Infrastructure
- **Database**: Neon PostgreSQL serverless database
- **AI Services**: OpenAI API for GPT-4o language model integration
- **Development Platform**: Replit for cloud development environment

### Frontend Libraries
- **UI Components**: Radix UI primitives for accessible component foundation
- **Charts & Visualization**: Recharts for progress tracking and competency visualization
- **Date Handling**: date-fns for date manipulation and formatting
- **Styling**: Tailwind CSS with class-variance-authority for component variants

### Backend Services
- **Database Driver**: @neondatabase/serverless for PostgreSQL connection
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **Validation**: Zod for runtime type validation and schema definition
- **Build Tools**: esbuild for production builds and tsx for development

### Development Tools
- **Build System**: Vite with React plugin and TypeScript support
- **Code Quality**: TypeScript for static type checking
- **Package Management**: npm with lockfile for dependency consistency
- **Hot Reload**: Vite HMR with custom error overlay for development experience